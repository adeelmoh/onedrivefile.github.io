$(document).ready(function(){
    
    $("#showPanel").click(function(){
        $("#panel").fadeIn("slow");
    });
    
    $("#hidePanel").click(function(){
        $("#panel").fadeOut("slow");
    });
  
});